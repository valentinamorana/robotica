package com.example.ledcontroller;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String DEVICE_ADDRESS = "58:56:00:00:CD:7E"; // tu HC-05
    private static final UUID MY_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private static final int REQ_BT_CONNECT = 1001;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;

    private Button connectBtn, allBtn, leftBtn, rightBtn, centerBtn;
    private Switch soundSwitch;
    private SeekBar brightnessSeek;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        connectBtn = findViewById(R.id.connectBtn);
        soundSwitch = findViewById(R.id.soundSwitch);
        brightnessSeek = findViewById(R.id.brightnessSeek);
        allBtn = findViewById(R.id.allBtn);
        leftBtn = findViewById(R.id.leftBtn);
        rightBtn = findViewById(R.id.rightBtn);
        centerBtn = findViewById(R.id.centerBtn);

        connectBtn.setOnClickListener(v -> connectToHC05());
        soundSwitch.setOnCheckedChangeListener((b, checked) -> sendCommand(checked ? "SOUND_ON" : "SOUND_OFF"));
        brightnessSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sendCommand("BRIGHT:" + progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        allBtn.setOnClickListener(v -> sendCommand("ALL"));
        leftBtn.setOnClickListener(v -> sendCommand("LEFT"));
        rightBtn.setOnClickListener(v -> sendCommand("RIGHT"));
        centerBtn.setOnClickListener(v -> sendCommand("CENTER"));
    }

    /** Devuelve true si ya tenemos permiso BLUETOOTH_CONNECT (solo necesario en Android 12+) */
    private boolean ensureBtConnectPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        REQ_BT_CONNECT
                );
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_CONNECT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                connectToHC05(); // reintenta conectar
            } else {
                Toast.makeText(this, "Permiso Bluetooth denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void connectToHC05() {
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth no disponible", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "Activa el Bluetooth", Toast.LENGTH_SHORT).show();
            return;
        }
        // Verificar/solicitar permiso antes de usar APIs sensibles
        if (!ensureBtConnectPermission()) return;

        try {
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(DEVICE_ADDRESS);
            bluetoothSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();
            outputStream = bluetoothSocket.getOutputStream();
            Toast.makeText(this, "Conectado a HC-05", Toast.LENGTH_SHORT).show();
        } catch (SecurityException se) {
            // Por si el usuario deniega el permiso mientras tanto
            Toast.makeText(this, "Falta permiso BLUETOOTH_CONNECT", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error al conectar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void sendCommand(String cmd) {
        if (outputStream == null) {
            Toast.makeText(this, "No conectado", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            outputStream.write((cmd + "\n").getBytes());
        } catch (IOException e) {
            Toast.makeText(this, "Error al enviar comando", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { if (outputStream != null) outputStream.close(); } catch (IOException ignored) {}
        try { if (bluetoothSocket != null) bluetoothSocket.close(); } catch (IOException ignored) {}
    }
}
